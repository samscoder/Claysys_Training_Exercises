$(document).ready(function() {
    // Handle focusout on email field
    $('#email').focusout(function() {
        validateEmailField();
    });

    // Handle focusout on password field
    $('#password').focusout(function() {
        validatePasswordField();
    });

    // Validate the form on submission
    $('#loginForm').submit(function(event) {
        event.preventDefault();

        // Clear previous validation messages
        $('.error').remove();

        // Validate all fields
        var isValidEmail = validateEmailField();
        var isValidPassword = validatePasswordField();

        // If valid, proceed with form submission
        if (isValidEmail && isValidPassword) {
            window.location.href = 'home.html'; // Redirect to home.html
        }
    });

    // Function to validate the email field
    function validateEmailField() {
        var email = $('#email').val();
        $('.error.email-error').remove(); // Remove any previous error messages for email

        if (!validateEmail(email)) {
            $('#email').after('<span class="error email-error">Enter a valid email address</span>');
            return false;
        }
        return true;
    }

    // Function to validate the password field
    function validatePasswordField() {
        var password = $('#password').val();
        $('.error.password-error').remove(); // Remove any previous error messages for password

        // Check for at least 8 characters, 1 alphabet, 1 number, 1 uppercase, and 1 special character
        var passwordPolicy = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;

        if (!passwordPolicy.test(password)) {
            $('#password').after('<span class="error password-error">Password must be at least 8 characters long, contain at least one uppercase letter, one number, and one special character</span>');
            return false;
        }
        return true;
    }

    // Email validation function
    function validateEmail(email) {
        var regex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
        return regex.test(email);
    }
});
