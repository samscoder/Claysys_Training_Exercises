﻿using System;
using System.Data;
using System.Data.SqlClient;

class Program
{
    // Define the connection string
    private static string connectionString = @"Data Source=SK\SQLEXPRESS;Initial Catalog=claysys;Integrated Security=True;";

    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Choose an option:");
            Console.WriteLine("1. Create User");
            Console.WriteLine("2. Read Users");
            Console.WriteLine("3. Update User");
            Console.WriteLine("4. Delete User");
            Console.WriteLine("5. Exit");
            Console.Write("Enter your choice: ");
            
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    CreateUser();
                    break;
                case 2:
                    ReadUsers();
                    break;
                case 3:
                    UpdateUser();
                    break;
                case 4:
                    DeleteUser();
                    break;
                case 5:
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    // Method to create a new user
    static void CreateUser()
    {
        Console.Write("Enter Name: ");
        string name = Console.ReadLine();

        Console.Write("Enter Email: ");
        string email = Console.ReadLine();

        Console.Write("Enter Password: ");
        string password = Console.ReadLine();

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "INSERT INTO Users (Name, Email, Password) VALUES (@Name, @Email, @Password)";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Password", password);
                
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                
                Console.WriteLine("User created successfully.");
            }
        }
    }

    // Method to read and display all users
    static void ReadUsers()
    {
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "SELECT * FROM Users";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                Console.WriteLine("ID\tName\tEmail\tPassword");
                while (reader.Read())
                {
                    Console.WriteLine($"{reader["Id"]}\t{reader["Name"]}\t{reader["Email"]}\t{reader["Password"]}");
                }

                con.Close();
            }
        }
    }

    // Method to update an existing user
    static void UpdateUser()
    {
        Console.Write("Enter User ID to update: ");
        int userId = int.Parse(Console.ReadLine());

        Console.Write("Enter New Name: ");
        string name = Console.ReadLine();

        Console.Write("Enter New Email: ");
        string email = Console.ReadLine();

        Console.Write("Enter New Password: ");
        string password = Console.ReadLine();

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "UPDATE Users SET Name = @Name, Email = @Email, Password = @Password WHERE Id = @UserId";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@UserId", userId);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Password", password);
                
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                
                Console.WriteLine("User updated successfully.");
            }
        }
    }

    // Method to delete a user
    static void DeleteUser()
    {
        Console.Write("Enter User ID to delete: ");
        int userId = int.Parse(Console.ReadLine());

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            string query = "DELETE FROM Users WHERE Id = @UserId";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@UserId", userId);
                
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                
                Console.WriteLine("User deleted successfully.");
            }
        }
    }
}
