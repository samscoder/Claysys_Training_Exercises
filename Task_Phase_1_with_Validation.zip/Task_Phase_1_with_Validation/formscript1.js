// Function to handle file input for signature image
function loadFile(event) {
    var output = document.getElementById('signature-img');
    output.src = URL.createObjectURL(event.target.files[0]); // Set the src of the image to the file selected
    output.onload = function () {
        URL.revokeObjectURL(output.src); // Release the object URL after the image has been loaded
    }
    validateSignatureFile();
}
// Function to validate the First Name input
function validateFName() {
    const firstName = document.getElementById('firstname');
    const firstp = /^[A-Za-z]+[\s]?$/; // Regular expression for validating first name

    if (firstName.value.trim() === '') {
        setError(firstName, "First name cannot be Empty");
    } else if (!firstp.test(firstName.value.trim())) {
        setError(firstName, "First name must only contain alphabets and cannot start with a space.");
    } else {
        setSuccess(firstName);
    }
}
// Function to validate the Last Name input
function validateLName() {
    const lastName = document.getElementById('lastname');
    const lastp = /^[A-Za-z]+[\s]?$/; // Regular expression for validating last name

    if (lastName.value.trim() === '') {
        setError(lastName, "Last name cannot be Empty");
    } else if (!lastp.test(lastName.value.trim())) {
        setError(lastName, "Last name must only contain alphabets and cannot start with a space.");
    } else {
        setSuccess(lastName);
    }
}
// Function to validate the Phone Number input
function validatePhone() {
    const phone = document.getElementById('phone');
    const phonePattern = /^[6-9]\d{9}$/; // Regular expression for validating phone number

    if (phone.value.trim() === '') {
        setError(phone, "Phone number cannot be Empty");
    } else if (!phonePattern.test(phone.value.trim())) {
        setError(phone, "Enter a valid phone number.");
    } else {
        setSuccess(phone);
    }
}
// Function to validate the Email input
function validateEmail() {
    const email = document.getElementById('email');
    const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/; // Regular expression for validating email

    if (email.value.trim() === '') {
        setError(email, "Email cannot be Empty");
    } else if (!emailPattern.test(email.value.trim())) {
        setError(email, "It should be of proper format");
    } else {
        setSuccess(email);
    }
}
// Function to validate the Address input
function validateAddress() {
    const address = document.getElementById('address');
    const addressPattern = /^[A-Za-z0-9\s-]+$/; // Regular expression for allowing alphabets, numbers, spaces, and dashes
    const isOnlyNumbers = /^\d+$/; // Regular expression for checking if the input is only numbers

    if (address.value.trim() === '') {
        setError(address, "Address cannot be empty");
    } else if (!addressPattern.test(address.value.trim())) {
        setError(address, "Address must only contain alphabets, numbers, spaces, and dashes");
    } else if (isOnlyNumbers.test(address.value.trim())) {
        setError(address, "Address cannot be just numbers");
    } else {
        setSuccess(address);
    }
}
// Function to validate the City input
function validateCity() {
    const city = document.getElementById('city');
    const cityPattern = /^[A-Za-z\s]+$/; // Regular expression for validating city name

    if (city.value.trim() === '') {
        setError(city, "City cannot be empty");
    } else if (!cityPattern.test(city.value.trim())) {
        setError(city, "City must only contain alphabets");
    } else {
        setSuccess(city);
    }
}
// Function to validate the State input
function validateState() {
    const state = document.getElementById('state');
    const statePattern = /^[A-Za-z\s]+$/; // Regular expression for validating state name

    if (state.value.trim() === '') {
        setError(state, "State cannot be empty");
    } else if (!statePattern.test(state.value.trim())) {
        setError(state, "State must only contain alphabets");
    } else {
        setSuccess(state);
    }
}
// Function to validate the Source of Discovery input
function validateSource() {
    const source = document.getElementById('source');
    const sourcePattern = /^[A-Za-z0-9\-\.\/]+$/; // Regular expression for allowing alphabets, numbers, dashes, dots, and slashes
    const isOnlyNumbers = /^\d+$/; // Regular expression for checking if the input is only numbers

    if (source.value.trim() === '') {
        setError(source, "Source field cannot be empty");
    } else if (!sourcePattern.test(source.value.trim())) {
        setError(source, "Enter a valid source");
    } else if (isOnlyNumbers.test(source.value.trim())) {
        setError(source, "Source cannot be just numbers");
    } else {
        setSuccess(source);
    }
}
// Function to validate the Company/Organization input
function validateCompany() {
    const company = document.getElementById('company');
    const companyPattern = /^[A-Za-z\s]+$/; // Regular expression for allowing only alphabets and spaces

    if (company.value.trim() === '') {
        setError(company, "Company/Organization cannot be empty");
    } else if (!companyPattern.test(company.value.trim())) {
        setError(company, "Company/Organization must only contain alphabets and spaces");
    } else {
        setSuccess(company);
    }
}
// Function to validate the Members input
function validateMembers() {
    const members = document.getElementById('members');
    const membersPattern = /^\d+$/; // Regular expression for digits

    if (members.value.trim() === '') {
        setError(members, "Members field cannot be empty");
    } else if (!membersPattern.test(members.value.trim())) {
        setError(members, "Members field must only contain digits");
    } else {
        setSuccess(members);
    }
}
// Function to validate the Special Instructions input
function validateInstructions() {
    const instructions = document.getElementById('instructions');

    if (instructions.value.trim() === '') {
        setError(instructions, "Special instructions cannot be empty");
    } else {
        setSuccess(instructions);
    }
    validateCheckboxGroup('.hotspot');
}
// Function to validate checkbox groups
function validateCheckboxGroup(groupName) {
    const form = document.querySelector(groupName);
    const checkboxes = form.querySelectorAll('input[type=checkbox]');
    const errorMessage = form.querySelector('small');
    const checkedCheckboxes = Array.from(checkboxes).filter(checkbox => checkbox.checked);

    if (checkedCheckboxes.length === 0) {
        // No checkbox is selected
        errorMessage.className = 'smallshown';
        errorMessage.innerHTML = "Please select at least one option";
        setError(checkboxes[0], "Please select at least one option");
    } else {
        // At least one checkbox is selected
        errorMessage.className = 'smallhidden';
        errorMessage.innerHTML = "";
        setSuccess(checkboxes[0]);
    }
}


// Function to validate the Signature Name input
function validateSignatureName() {
    const name = document.getElementById('name');

    const namePattern = /^[A-Za-z\s]+$/; // Regular expression for allowing only alphabets and spaces

    if (name.value.trim() === '') {
        setError(name, "Signature name cannot be empty");
    } else if (!namePattern.test(name.value.trim())) {
        setError(name, "Enter a valid name");
    } else {
        setSuccess(name);
    }
}
// Function to validate the Signature File input
function validateSignatureFile() {
    const signatureFile = document.getElementById('signature');

    if (signatureFile.files.length === 0) {
        setError(signatureFile, "Signature file cannot be empty");
    } else {
        setSuccess(signatureFile);
    }
}
// Function to set today's date in the date input field
function vDate() {
    const dateInput = document.getElementById('date');
    const today = new Date();

    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();

    const formattedDate = `${dd}-${mm}-${yyyy}`;

    dateInput.value = formattedDate;
}
// Set the date when the window loads
window.onload = vDate;

// Function to check validation of all form fields
function checkValidation() {
    validateFName();
    validateLName();
    validateEmail();
    validatePhone();
    validateAddress();
    validateCity();
    validateState();
    validateSource();
    validateCompany();
    validateMembers();
    validateInstructions();
    validateSignatureName();
    validateSignatureFile();
    validateCheckboxGroup(selector);
}

// Function to set an error message and disable the submit button
function setError(input, message) {
    let submitbutton = document.getElementById("button");
    const formControl = input.parentElement;
    const small = formControl.querySelector('small');
    small.className = 'smallshown';
    small.innerHTML = message;
    submitbutton.disabled = true;
}

// Function to clear error messages and enable the submit button
function setSuccess(input) {
    let submitbutton = document.getElementById("button");
    const formControl = input.parentElement;
    const small = formControl.querySelector('small');
    small.className = 'smallhidden';
    small.innerHTML = "";
    submitbutton.disabled = false;
}
