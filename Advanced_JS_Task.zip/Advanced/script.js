// Task 1: Object-Oriented Programming
class Car {
    constructor(make, model) {
        this.make = make;
        this.model = model;
    }

    drive() {
        return `The ${this.make} ${this.model} is driving.`;
    }
}

function createCar() {
    let myCar = new Car('Toyota', 'Corolla');
    document.getElementById("carResult").textContent = myCar.drive();
}


// Task 2: API Requests
async function fetchData() {
    // Prompt the user to enter the API URL
    let apiUrl = prompt("Please enter the API URL:", "https://jsonplaceholder.typicode.com/posts/1");
    
    // Check if the user entered a URL
    if (apiUrl) {
        try {
            let response = await fetch(apiUrl);
            let data = await response.json();
            document.getElementById("apiResult").textContent = `Title: ${data.title}`;
        } catch (error) {
            document.getElementById("apiResult").textContent = "Error fetching data.";
        }
    } else {
        document.getElementById("apiResult").textContent = "No URL entered.";
    }
}

// Task 3: Single Page Application (SPA)
function showPage(page) {
    let content = '';
    if (page === 'home') content = 'Welcome to the Home page!';
    else if (page === 'about') content = 'This is the About page.';
    else if (page === 'contact') content = 'You are on the Contact page.';
    document.getElementById("spaContent").textContent = content;
}

// Task 4: Local Storage
// Task 4: Local Storage
function storeData() {
    let data = document.getElementById("storageInput").value;
    let storedData = JSON.parse(localStorage.getItem('myData')) || [];

    if (!Array.isArray(storedData)) {
        storedData = [];
    }

    storedData.push(data);
    localStorage.setItem('myData', JSON.stringify(storedData));

    document.getElementById("storageResult").textContent = "Data stored!";
    document.getElementById("storageInput").value = "";
}

function retrieveData() {
    let storedData = JSON.parse(localStorage.getItem('myData'));

    if (storedData && Array.isArray(storedData) && storedData.length > 0) {
        document.getElementById("storageResult").textContent = "Stored Data: " + storedData.join(", ");
    } else {
        document.getElementById("storageResult").textContent = "No data found.";
    }
}

function clearStorage() {
    localStorage.removeItem('myData');
    document.getElementById("storageResult").textContent = "Storage cleared!";
}

// Task 5: Asynchronous JavaScript
async function asyncOperation() {
    document.getElementById("asyncResult").textContent = "Loading...";
    let result = await new Promise(resolve => setTimeout(() => resolve("Async operation completed!"), 2000));
    document.getElementById("asyncResult").textContent = result;
}