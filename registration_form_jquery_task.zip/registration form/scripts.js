$(document).ready(function () {
    // Set max attribute to today's date
    const today = new Date().toISOString().split('T')[0];
    $('#dob').attr('max', today);

    // Initialize Select2 for state and city dropdowns
    $('#state').select2({
        placeholder: "Select State"
    });
    $('#city').select2({
        placeholder: "Select City"
    });

    // Define the states and cities
    const citiesByState = {
        AndhraPradesh: ["Visakhapatnam", "Vijayawada", "Guntur", /* Other cities */],
        // Define other states and cities
    };

    // Populate state dropdown
    const $stateSelect = $('#state');
    Object.keys(citiesByState).forEach(function(state) {
        $stateSelect.append(`<option value="${state}">${state}</option>`);
    });

    // Handle state dropdown change event
    $('#state').change(function() {
        const selectedState = $(this).val();
        const $citySelect = $('#city');

        // Clear existing options in the city dropdown
        $citySelect.empty().append('<option value="">Select City</option>');

        // If a valid state is selected, populate the city dropdown
        if (selectedState && citiesByState[selectedState]) {
            citiesByState[selectedState].forEach(function(city) {
                const value = city.toLowerCase().replace(/\s+/g, '-');
                $citySelect.append(`<option value="${value}">${city}</option>`);
            });
        }

        // Refresh Select2 to update city options
        $citySelect.trigger('change');
    });

    // Refresh Select2 for the city dropdown after it is populated
    $('#city').select2({
        placeholder: "Select City"
    });

    // Initialize jQuery Validation
    $('#myForm').validate({
        rules: {
            firstName: {
                required: true,
                letters: true
            },
            lastName: {
                required: true,
                letters: true
            },
            dob: {
                required: true,
                date: true
            },
            phone: {
                required: true,
                phoneIN: true
            },
            address: {
                required: true,
                alphanumeric: true
            },
            username: {
                required: true,
                alphanumeric: true
            },
            email: {
                required: true,
                email: true
            },
            password: {
                required: true,
                minlength: 8,
                regex: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/
            },
            confirmPassword: {
                required: true,
                equalTo: "#password"
            },
            state: {
                required: true
            },
            city: {
                required: true
            }
        },
        messages: {
            firstName: {
                required: "This field is required.",
                letters: "Name should contain only alphabets."
            },
            lastName: {
                required: "This field is required.",
                letters: "Name should contain only alphabets."
            },
            // Add custom messages for other fields
        },
        errorElement: "span",
        errorPlacement: function (error, element) {
            error.addClass("error");
            error.insertAfter(element);
        },
        success: function (label) {
            label.remove();
        }
    });

    // Custom validation method for letters only
    $.validator.addMethod("letters", function (value, element) {
        return this.optional(element) || /^[A-Za-z]+$/.test(value);
    });

    // Custom validation method for phone number format
    $.validator.addMethod("phoneIN", function (value, element) {
        return this.optional(element) || /^[6-9]\d{9}$/.test(value);
    });

    // Custom validation method for alphanumeric characters
    $.validator.addMethod("alphanumeric", function (value, element) {
        return this.optional(element) || /^[A-Za-z0-9\s]+$/.test(value);
    });

    // Custom validation method for regex
    $.validator.addMethod("regex", function (value, element, regex) {
        return this.optional(element) || regex.test(value);
    });
});