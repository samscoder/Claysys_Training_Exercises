$(document).ready(function () {
     // Set max attribute to today's date
     const today = new Date().toISOString().split('T')[0];
     $('#dob').attr('max', today);

      // Initialize Select2 for state and city dropdowns
    $('#state1').select2({
        placeholder: "Select State"
    });
    $('#city1').select2({
        placeholder: "Select City"
    });

    // Define the states and cities
    const citiesByState = {
        AndhraPradesh: ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool", "Rajahmundry", "Tirupati", "Kakinada", "Anantapur", "Eluru", "Ongole", "Adoni", "Madanapalle", "Machilipatnam", "Tenali", "Proddatur", "Hindupur", "Chittoor", "Srikakulam", "Narasaraopet"],
        ArunachalPradesh: ["Itanagar", "Tawang", "Ziro", "Pasighat", "Bomdila", "Tezu", "Along", "Namsai", "Roing", "Daporijo", "Seppa", "Anini", "Basar", "Khonsa", "Changlang", "Yingkiong", "Mechuka", "Koloriang", "Longding", "Deomali"],
        Assam: ["Guwahati", "Silchar", "Dibrugarh", "Jorhat", "Nagaon", "Tinsukia", "Tezpur", "Bongaigaon", "Dhubri", "North Lakhimpur", "Sivasagar", "Goalpara", "Barpeta", "Karimganj", "Lanka", "Diphu", "Hojai", "Golaghat", "Morigaon", "Mangaldoi"],
        Bihar: ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Darbhanga", "Purnia", "Chhapra", "Katihar", "Munger", "Arrah", "Begusarai", "Saharsa", "Bettiah", "Sitamarhi", "Motihari", "Sasaram", "Hajipur", "Dehri", "Siwan", "Kishanganj"],
        Chhattisgarh: ["Raipur", "Bhilai", "Bilaspur", "Korba", "Durg", "Raigarh", "Jagdalpur", "Rajnandgaon", "Ambikapur", "Dhamtari", "Mahasamund", "Chirmiri", "Bhatapara", "Dalli-Rajhara", "Tilda", "Akaltara", "Kurud", "Birgaon", "Kawardha", "Dongargaon"],
        Goa: ["Panaji", "Margao", "Vasco da Gama", "Mapusa", "Ponda", "Bicholim", "Valpoi", "Curchorem", "Canacona", "Sanquelim", "Sanguem", "Quepem", "Pernem", "Mormugao", "Pilerne", "Aldona", "Chinchinim", "Dabolim", "Chandor", "Usgao"],
        Gujarat: ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Gandhinagar", "Junagadh", "Anand", "Navsari", "Surendranagar", "Nadiad", "Morbi", "Bharuch", "Porbandar", "Godhra", "Mehsana", "Patan", "Vapi", "Dahod"],
        Haryana: ["Gurugram", "Faridabad", "Panipat", "Ambala", "Yamunanagar", "Rohtak", "Hisar", "Karnal", "Sonipat", "Panchkula", "Bhiwani", "Jind", "Bahadurgarh", "Sirsa", "Thanesar", "Kaithal", "Palwal", "Rewari", "Fatehabad", "Hansi"],
        HimachalPradesh: ["Shimla", "Dharamshala", "Manali", "Mandi", "Solan", "Hamirpur", "Una", "Bilaspur", "Chamba", "Nahan", "Kullu", "Paonta Sahib", "Palampur", "Kangra", "Sundarnagar", "Baddi", "Nalagarh", "Rohru", "Keylong", "Rampur"],
        Jharkhand: ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro", "Deoghar", "Hazaribagh", "Giridih", "Ramgarh", "Phusro", "Gumla", "Lohardaga", "Medininagar", "Chaibasa", "Chatra", "Godda", "Sahibganj", "Pakur", "Simdega", "Khunti", "Latehar"],
        Karnataka: ["Bengaluru", "Mysuru", "Mangaluru", "Hubballi", "Dharwad", "Belagavi", "Kalaburagi", "Davangere", "Ballari", "Vijayapura", "Shivamogga", "Tumakuru", "Udupi", "Bidar", "Raichur", "Chitradurga", "Gadag", "Kolar", "Mandya", "Chikkamagaluru"],
        Kerala: ["Thiruvananthapuram", "Kochi", "Kollam", "Calicut", "Thrissur", "Alappuzha", "Palakkad", "Kannur", "Kottayam", "Kasaragod", "Idukki", "Malappuram", "Pathanamthitta", "Varkala", "Kayamkulam", "Punalur", "Adoor", "Nedumangad", "Perumbavoor", "Ottapalam"],
        MadhyaPradesh: ["Indore", "Bhopal", "Jabalpur", "Gwalior", "Ujjain", "Sagar", "Dewas", "Satna", "Ratlam", "Rewa", "Murwara", "Singrauli", "Burhanpur", "Khandwa", "Chhindwara", "Vidisha", "Guna", "Chhatarpur", "Sehore", "Mandsaur"],
        Maharashtra: ["Mumbai", "Pune", "Nagpur", "Nashik", "Thane", "Aurangabad", "Solapur", "Kalyan-Dombivli", "Vasai-Virar", "Navi Mumbai", "Kolhapur", "Amravati", "Akola", "Jalgaon", "Sangli", "Latur", "Ahmednagar", "Dhule", "Malegaon", "Chandrapur"],
        Manipur: ["Imphal", "Thoubal", "Kakching", "Bishnupur", "Senapati", "Ukhrul", "Churachandpur", "Moreh", "Moirang", "Nambol", "Jiribam", "Lilong", "Wangjing", "Yairipok", "Kangpokpi", "Mayang Imphal", "Andro", "Lamlai", "Nongpok Sekmai", "Lamshang"],
        Meghalaya: ["Shillong", "Tura", "Nongstoin", "Jowai", "Baghmara", "Williamnagar", "Nongpoh", "Cherrapunji", "Mawkyrwat", "Resubelpara", "Byrnihat", "Umiam", "Tikrikilla", "Mairang", "Nongalbibra", "Ranikor", "Mawphlang", "Sohra", "Mawlynnong", "Smit"],
        Mizoram: ["Aizawl", "Lunglei", "Saiha", "Champhai", "Kolasib", "Serchhip", "Mamit", "Lawngtlai", "Bairabi", "Vairengte", "Saitual", "Hnahthial", "Darlawn", "Tlabung", "Khawzawl", "Zawlnuam", "Reiek", "North Vanlaiphai", "Ngopa", "Phullen"],
        Nagaland: ["Kohima", "Dimapur", "Mokokchung", "Tuensang", "Wokha", "Zunheboto", "Mon", "Phek", "Kiphire", "Longleng", "Tseminyu", "Chumukedima", "Pfutsero", "Meluri", "Jalukie", "Aboi", "Shamator", "Medziphema", "Naginimora", "Aghunato"],
        Odisha: ["Bhubaneswar", "Cuttack", "Rourkela", "Berhampur", "Sambalpur", "Puri", "Balasore", "Baripada", "Bhadrak", "Jharsuguda", "Jeypore", "Dhenkanal", "Bargarh", "Paradip", "Koraput", "Rayagada", "Angul", "Kendujhar", "Nabarangpur", "Sonepur"],
        Punjab: ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda", "Mohali", "Hoshiarpur", "Batala", "Pathankot", "Moga", "Malerkotla", "Firozpur", "Abohar", "Phagwara", "Kapurthala", "Faridkot", "Barnala", "Mansa", "Sangrur", "Rupnagar"],
        Rajasthan: ["Jaipur", "Jodhpur", "Kota", "Bikaner", "Ajmer", "Udaipur", "Bhilwara", "Alwar", "Bharatpur", "Sri Ganganagar", "Pali", "Sikar", "Hanumangarh", "Dhaulpur", "Beawar", "Barmer", "Tonk", "Churu", "Bundi", "Jaisalmer"],
        Sikkim: ["Gangtok", "Namchi", "Geyzing", "Mangan", "Rangpo", "Singtam", "Jorethang", "Nayabazar", "Yuksom", "Ravangla", "Chungthang", "Zuluk", "Pakyong", "Dentam", "Rongli", "Lachen", "Lachung", "Tsomgo", "Pelling", "Kaluk"],
        Tamilnadu: ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli", "Erode", "Vellore", "Tirupur", "Thoothukudi", "Dindigul", "Thanjavur", "Ranipet", "Karur", "Cuddalore", "Nagercoil", "Kanchipuram", "Kumbakonam", "Pudukkottai", "Nagapattinam"],
        Telangana: ["Hyderabad", "Warangal", "Nizamabad", "Khammam", "Karimnagar", "Ramagundam", "Mahbubnagar", "Nalgonda", "Adilabad", "Suryapet", "Siddipet", "Jagtial", "Kamareddy", "Bhongir", "Miryalaguda", "Mancherial", "Vikarabad", "Wanaparthy", "Tandur", "Nagarkurnool"],
        Tripura: ["Agartala", "Dharmanagar", "Kailashahar", "Udaipur", "Ambassa", "Belonia", "Khowai", "Sabroom", "Sonamura", "Amarpur", "Ranirbazar", "Teliamura", "Mohanpur", "Melaghar", "Bishalgarh", "Jirania", "Panisagar", "Bamutia", "Fatikroy", "Kumarghat"],
        UttarPradesh: ["Lucknow", "Kanpur", "Ghaziabad", "Agra", "Meerut", "Varanasi", "Prayagraj", "Bareilly", "Aligarh", "Moradabad", "Saharanpur", "Gorakhpur", "Noida", "Firozabad", "Jhansi", "Shahjahanpur", "Rampur", "Muzaffarnagar", "Mathura", "Budaun"],
        Uttarakhand: ["Dehradun", "Haridwar", "Roorkee", "Haldwani", "Rudrapur", "Kashipur", "Rishikesh", "Pithoragarh", "Ramnagar", "Almora", "Nainital", "Khatima", "Bageshwar", "Kotdwar", "Mussoorie", "Champawat", "Tehri", "Srinagar", "Uttarkashi", "Gopeshwar"],
        WestBengal: ["Kolkata", "Asansol", "Siliguri", "Durgapur", "Howrah", "Bardhaman", "Kharagpur", "Darjeeling", "Jalpaiguri", "Malda", "Nadia", "Alipurduar", "Cooch Behar", "Bankura", "Medinipur", "Bally", "Basirhat", "Raiganj", "Haldia", "Chinsurah"]
        
    };

    // Populate state dropdown
    const $stateSelect = $('#state');
    Object.keys(citiesByState).forEach(function(state) {
        $stateSelect.append(`<option value="${state}">${state}</option>`);
    });

    // Handle state dropdown change event
    $('#state').change(function() {
        const selectedState = $(this).val();
        const $citySelect = $('#city');

        // Clear existing options in the city dropdown
        $citySelect.empty().append('<option value="">Select City</option>');

        // If a valid state is selected, populate the city dropdown
        if (selectedState && citiesByState[selectedState]) {
            citiesByState[selectedState].forEach(function(city) {
                const value = city.toLowerCase().replace(/\s+/g, '-');
                $citySelect.append(`<option value="${value}">${city}</option>`);
            });
        }

        // Refresh Select2 to update city options
        $citySelect.trigger('change');
    });

    // Apply focusout validation for state and city fields
    $('#state').focusout(function () {
        const input = $(this);
        if (input.val() === '') {
            showError(input, "This field is required.");
        } else {
            hideError(input);
        }
    });

    $('#city').focusout(function () {
        const input = $(this);
        if (input.val() === '') {
            showError(input, "This field is required.");
        } else {
            hideError(input);
        }
    });

    // Validate each field on focus out
    $('#firstName, #lastName').focusout(function () {
        const nameRegex = /^[A-Za-z]+$/;
        const input = $(this);
        if (input.val() === '') {
            showError(input, "This field is required.");
        } else if (!nameRegex.test(input.val())) {
            showError(input, "Name should contain only alphabets.");
        } else {
            hideError(input);
        }
    });

    $('#dob').focusout(function () {
        const input = $(this);
        const dob = new Date(input.val());
        const today = new Date();
        if (input.val() === '') {
            showError(input, "This field is required.");
        } else if (dob > today) {
            showError(input, "Date of Birth cannot be in the future.");
        } else {
            hideError(input);
        }
    });

    $('#phone').focusout(function () {
        const phoneRegex = /^[6-9]\d{9}$/;
        const input = $(this);
        if (input.val() === '') {
            showError(input, "This field is required.");
        } else if (!phoneRegex.test(input.val())) {
            showError(input, "Phone number should follow the format 9876543210.");
        } else {
            hideError(input);
        }
    });

    $("#address").focusout(function () {
        const addressRegex = /^[A-Za-z0-9\s]+$/;
        const input = $(this);
        if (input.val().trim() === "") {
            showError(input, "Address cannot be empty.");
        } else if (!addressRegex.test(input.val())) {
            showError(input, "Address should be a combination of alphabets and numbers.");
        } else {
            hideError(input);
        }
    });

    // Username Validation (Must contain alphabets, may contain numbers, non-empty)
    $("#username").focusout(function () {
        const usernameRegex = /^(?=.*[a-z_.])[a-z0-9_.]+$/;
        const input = $(this);
        const username = input.val().trim();
    
        if (username === "") {
            showError(input, "Username cannot be empty.");
        } else if (/[A-Z]/.test(username)) {
            showError(input, "Username must contain only lowercase letters.");
        } else if (!usernameRegex.test(username)) {
            showError(input, "Username must contain only lowercase letters, numbers, underscores, and periods, and must include at least one lowercase letter.");
        } else {
            hideError(input);
        }
    });


    $('#email').focusout(function () {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const input = $(this);
        if (input.val() === '') {
            showError(input, "This field is required.");
        } else if (!emailRegex.test(input.val())) {
            showError(input, "Please enter a valid email address.");
        } else {
            hideError(input);
        }
    });

    $('#password').focusout(function () {
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/;
        const input = $(this);
        if (input.val() === '') {
            showError(input, "This field is required.");
        } else if (!passwordRegex.test(input.val())) {
            showError(input, "Password must be at least 8 characters long, include upper and lower case letters, a number, and a special character.");
        } else {
            hideError(input);
        }
    });

    $('#confirmPassword').focusout(function () {
        const password = $("#password").val();
        const confirmPassword = $(this).val();
        if (confirmPassword === '') {
            showError($(this), "This field is required.");
        } else if (password !== confirmPassword) {
            showError($(this), "Passwords do not match.");
        } else {
            hideError($(this));
        }
    });

   /* $('#state1').focusout(function () {
        const input = $(this);
        if (input.val() === '') {
            showError(input, "This field is required.");
        } else {
            hideError(input);
        }
    });

    $('#city1').focusout(function () {
        const input = $(this);
        if (input.val() === '') {
            showError(input, "This field is required.");
        } else {
            hideError(input);
        }
    });*/

    $('#btn-primary').click(function (event) {
        // Prevent the default form submission
        event.preventDefault();

        // Validate all fields again
        $('#firstName, #lastName, #dob, #phone, #address, #username, #email, #password, #confirmPassword, #state, #city').trigger('focusout');

        // Check if there are any visible errors
        if ($('.error:visible').length === 0) {
            // All validations passed, navigate to home.html
            window.location.href = 'home.html';
        } else {
            // Scroll to the first error if there are any
            $('html, body').animate({
                scrollTop: $('.error:visible').first().offset().top - 20
            }, 500);
        }
    });
    // Function to display error
    function showError(input, message) {
        let errorElement = input.next(".error");
        if (errorElement.length === 0) {
            errorElement = $("<span class='error'></span>").insertAfter(input);
        }
        errorElement.text(message).css("color", "red");
    }

    // Function to hide error
    function hideError(input) {
        input.next(".error").remove();
    }
});
