const todoIn = document.getElementById("todo");
const btn = document.getElementById("btn");
const list = document.getElementById("list-todo");

function Addtask() {
    const task = todoIn.value;

    if (task === '') {
        alert('Enter a Task to Add!');
        return;
    }

    const li = document.createElement('li');

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'checkbox';
    checkbox.onchange = function() {
        li.classList.toggle('completed');
    };
    
    const span = document.createElement('span');
    span.textContent = task;

    const rbtn = document.createElement('button');
    rbtn.textContent = 'Remove';
    rbtn.className = 'rembtn';
    rbtn.onclick =  function() {
        list.removeChild(li);
    };

    li.appendChild(checkbox);
    li.appendChild(span);
    li.appendChild(rbtn);
    list.appendChild(li);

    todoIn.value = '';
}

btn.addEventListener('click', Addtask);